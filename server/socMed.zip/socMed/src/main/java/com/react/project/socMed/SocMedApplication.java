package com.react.project.socMed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocMedApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocMedApplication.class, args);
	}

}
