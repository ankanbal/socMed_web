package com.react.project.socMed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocMedApplicationTests {

	@Test
	void contextLoads() {
	}

}
